package at.kolleg.erplite.customermanagement.domain;

public record Address(String street, String zipcode, String city, String country) {
}
