package at.kolleg.erplite.customermanagement.usecases.commands;

public record CustomerUpdateCommand() {
}
