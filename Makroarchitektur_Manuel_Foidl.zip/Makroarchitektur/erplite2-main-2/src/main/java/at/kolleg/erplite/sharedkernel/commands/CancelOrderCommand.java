package at.kolleg.erplite.sharedkernel.commands;

public record CancelOrderCommand() {
}
