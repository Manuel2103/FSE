package at.kolleg.erplite.sharedkernel.events;

public record OrderInDeliveryEvent(String orderID) {
}
